#ifndef MEMREQ_H
#define MEMREQ_h

char* get_memory(unsigned num_bytes);

#endif /*MEMREQ_H*/
